#include "4a.h"
#include <stdio.h> /* für NULL */
#include <stdlib.h> /* für exit(int) */

void buddy_free(void *addr) {
  // Diese Funktion sollt ihr implementieren

  // Aufrechterhaltung der Invariante (vereinige Buddies, wo nötig)
  bst_housekeeping(bst_root());
}
