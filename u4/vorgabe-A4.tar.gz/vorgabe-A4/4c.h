#ifndef __4C_H__
#define __4C_H__

#include "4b.h"

void buddy_fast_free(void *addr);

#endif
