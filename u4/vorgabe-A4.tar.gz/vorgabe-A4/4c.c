#include "4c.h"
#include <stdio.h> /* für NULL */
#include <stdlib.h> /* für exit(int) */

void buddy_fast_free(void *addr)
{
	// Diese Funktion sollt ihr implementieren
}
