#ifndef __4A_H__
#define __4A_H__

#include "bst.h"

void buddy_free(void *addr);

#endif
