#include <stdio.h>
#include <stdlib.h>
/// Zusätzliche Header-Dateien hier!

#include "vorgabe.h"

void init_semaphores(){
	/// *** HIER EUER CODE ***
}

void destroy_semaphores(){
	/// *** HIER EUER CODE ***
}
