#include <stdlib.h>
#include <stdio.h>
/// Zusätzliche Header-Dateien hier!

#include "vorgabe.h"

void *work(void *arg){
	int my_num = *((int *)arg);

	printf("[BT %d] Ich bin bereit zu arbeiten!\n", my_num);

	/// *** HIER EUER CODE ***


	return NULL;
}
